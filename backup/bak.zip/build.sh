#backup
zip -r backup/bak.zip .

#compile to css
sass scss/ui.scss css/ui.css
