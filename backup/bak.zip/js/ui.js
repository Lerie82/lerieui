//paint the container for the dark navbar
conNav = document.querySelector('nav.dark').parentElement.setAttribute("style", "color:#cccccc; background:#232323");
