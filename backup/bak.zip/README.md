## Grid
The grid is a 12 column repeating grid

### Sections
Sections are basically "sections" trhat you are filling with content. There are several helper classes available to align your content:
- .two 
 - Gives the developer two sections
- .three
 - Allows for a section to have three panels
- .four
 - Yep, there is now four panels.

### Panels
Panels hold your content, panels belong inside of sections.

### Colors

### Headers

### Footers

### HTML Document

### Navbars
The nav HTML tag sits inside of the container tag. Some helper classes
- .right
 - pulls the menu right
